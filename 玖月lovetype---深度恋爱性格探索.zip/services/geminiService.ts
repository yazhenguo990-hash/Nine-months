
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || "";

export async function generateAIAnalysis(personalityCode: string, name: string) {
  if (!API_KEY) return "由于连接受限，深度洞察暂时无法开启。";

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = `
    你是一名懂心理学的人文情感专栏作家。请根据 MBTI 类型 "${personalityCode}" 为昵称为 "${name}" 的用户生成一份极具感染力的恋爱人格解析。
    
    要求：
    1. 语气：温润、文艺、感性且带有启发性，避免使用过多的冷冰冰的术语。
    2. 结构：
       - “灵魂底色”：描述这种性格在恋爱中最迷人的光芒。
       - “爱的盲点”：以温柔的方式提醒 Ta 可能会遇到的挑战。
       - “致未来的 Ta”：写一段写给 Ta 未来另一半的暖心“使用建议”。
       - “爱自己的方式”：一段鼓励 Ta 更好地接纳和爱自己的文字。
    
    字数要求：约300-400字，分段清晰。
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("AI Generation Error:", error);
    return "解析过程中出现了一点波折，但这并不影响你独特的魅力。";
  }
}
