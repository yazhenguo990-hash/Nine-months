
import React from 'react';

export const Header: React.FC = () => (
  <header className="bg-white/80 backdrop-blur-md py-4 px-6 shadow-sm flex justify-between items-center sticky top-0 z-50">
    <div className="flex items-center gap-2">
      <div className="w-10 h-10 gradient-pink rounded-xl flex items-center justify-center text-white shadow-lg shadow-pink-200">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
        </svg>
      </div>
      <div>
        <h1 className="font-bold text-lg text-gray-800 tracking-tight">玖月LoveType</h1>
        <p className="text-[10px] text-pink-400 font-medium tracking-widest uppercase">Love Discovery</p>
      </div>
    </div>
    <div className="text-[11px] font-medium text-gray-400 border border-gray-100 px-3 py-1 rounded-full bg-gray-50">
      探索未知的自己
    </div>
  </header>
);

export const Footer: React.FC = () => (
  <footer className="bg-gray-50 border-t border-gray-100 py-10 px-6 text-center">
    <div className="flex justify-center gap-4 mb-4">
      <div className="w-1 h-1 rounded-full bg-pink-200"></div>
      <div className="w-1 h-1 rounded-full bg-pink-200"></div>
      <div className="w-1 h-1 rounded-full bg-pink-200"></div>
    </div>
    <p className="text-gray-400 text-xs leading-relaxed">
      温馨提示：本产品仅供娱乐与自我探索使用，<br/>不作为任何心理咨询、诊断或医学建议。
    </p>
    <p className="mt-4 text-[10px] text-gray-300">© 2024 玖月LoveType 实验室</p>
  </footer>
);
