
import React, { useEffect, useState } from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { PersonalityType } from '../types';
import { generateAIAnalysis } from '../services/geminiService';

interface ResultReportProps {
  personality: PersonalityType;
  scores: Record<string, number>;
  userName: string;
}

export const ResultReport: React.FC<ResultReportProps> = ({ personality, scores, userName }) => {
  const [aiAnalysis, setAiAnalysis] = useState<string>('正在解析你的灵魂图谱，请稍候...');

  useEffect(() => {
    generateAIAnalysis(personality.code, userName).then(setAiAnalysis);
  }, [personality.code, userName]);

  // Use the scores (0-1 range) to plot the radar chart
  const chartData = [
    { subject: '外向能量', A: scores['E/I'] * 100 },
    { subject: '直觉灵敏', A: scores['S/N'] === 0 ? 100 : (1 - scores['S/N']) * 100 }, // S/N, where N is higher
    { subject: '感性深度', A: scores['T/F'] === 0 ? 100 : (1 - scores['T/F']) * 100 }, // T/F, where F is higher
    { subject: '随性指数', A: scores['J/P'] === 0 ? 100 : (1 - scores['J/P']) * 100 }, // J/P, where P is higher
  ];

  return (
    <div className="max-w-2xl mx-auto pb-12 animate-fadeIn">
      <div className="bg-white rounded-[2rem] shadow-2xl shadow-pink-100 overflow-hidden mb-8 border border-white">
        {/* Header Visual */}
        <div className="gradient-pink p-12 text-center text-white relative">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <svg width="100%" height="100%"><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/></pattern><rect width="100%" height="100%" fill="url(#grid)" /></svg>
          </div>
          <p className="text-pink-100 mb-2 font-light tracking-widest uppercase text-sm">Discovery Report</p>
          <h2 className="text-4xl font-black mb-3 drop-shadow-md">{personality.name}</h2>
          <div className="inline-block px-4 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium">
            {personality.tagline}
          </div>
        </div>

        <div className="p-8">
          {/* Personality Tags */}
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {personality.traits.map(trait => (
              <span key={trait} className="bg-pink-50 text-pink-500 rounded-full py-2 px-5 text-sm font-bold border border-pink-100">
                #{trait}
              </span>
            ))}
          </div>

          {/* Intro Section */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-1 h-6 bg-pink-500 rounded-full"></div>
              <h3 className="text-xl font-bold text-gray-800">内心独白</h3>
            </div>
            <p className="text-gray-600 leading-loose text-lg font-light italic">
              “{personality.description}”
            </p>
          </section>

          {/* Radar Chart */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-1 h-6 bg-pink-500 rounded-full"></div>
              <h3 className="text-xl font-bold text-gray-800">特质解析</h3>
            </div>
            <div className="h-72 bg-gray-50 rounded-3xl p-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                  <PolarGrid stroke="#e5e7eb" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#9ca3af', fontSize: 12, fontWeight: 500 }} />
                  <Radar name="My Score" dataKey="A" stroke="#f472b6" fill="#f472b6" fillOpacity={0.5} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </section>

          {/* Strategies */}
          <div className="grid gap-6 mb-12">
            <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-6 rounded-[1.5rem] border border-indigo-100">
              <h4 className="font-bold text-indigo-900 mb-3 flex items-center gap-2">
                <span className="text-xl">✨</span> 灵魂契合度
              </h4>
              <p className="text-indigo-800/80 text-sm leading-relaxed mb-4">
                你的能量场更容易被 <span className="font-bold text-indigo-600">{personality.compatibility.join('、')}</span> 类型的人所吸引。这种连接往往能超越言语。
              </p>
              <div className="p-4 bg-white/50 rounded-xl text-indigo-700 text-sm italic">
                建议：{personality.advice}
              </div>
            </div>
          </div>

          {/* AI Content */}
          <section className="bg-gray-50 p-8 rounded-[2rem] relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41" /></svg>
            </div>
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
               深度解读报告
            </h3>
            <div className="text-gray-600 leading-relaxed text-base font-light whitespace-pre-wrap">
              {aiAnalysis}
            </div>
            <div className="mt-6 pt-6 border-t border-gray-200">
              <p className="text-[11px] text-gray-400 italic">
                * 以上分析基于趣味模型生成，旨在帮助你更好地觉察自我，遇见更契合的Ta。
              </p>
            </div>
          </section>
        </div>
      </div>

      <div className="space-y-4">
        <button
          onClick={() => window.location.reload()}
          className="w-full bg-white border-2 border-pink-400 text-pink-500 font-bold py-4 rounded-full hover:bg-pink-50 transition-all shadow-lg shadow-pink-50"
        >
          重新探索
        </button>
        <p className="text-center text-gray-400 text-xs px-10 leading-relaxed">
          好的爱情从了解自己开始。<br/>邀请好友一起测评，发现你们的默契秘密。
        </p>
      </div>
    </div>
  );
};
